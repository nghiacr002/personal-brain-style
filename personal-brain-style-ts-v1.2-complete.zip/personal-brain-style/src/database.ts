import { DatabaseSync } from "node:sqlite";
import { randomUUID, randomBytes, createHmac } from "node:crypto";
import { mkdirSync, chmodSync } from "node:fs";
import { dirname, join } from "node:path";
import { homedir } from "node:os";
import { BrainError, DOMAINS, type BrainRecord, type Domain, type Feedback, type Kind, type RecordInput, type Revision, type TestRule, validDomain, validKind } from "./models.ts";

export const defaultHome = () => process.env.PB_HOME || join(homedir(), ".personal-brain-style");
export const dbPath = () => join(defaultHome(), "brain.sqlite");

function checkInput(raw: unknown): RecordInput {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new BrainError("Expected record object");
  const x = raw as Record<string, unknown>;
  if (!validKind(x.kind)) throw new BrainError("Invalid record kind");
  if (!validDomain(x.domain)) throw new BrainError("Invalid style domain");
  for (const field of ["title", "summary", "content"] as const) {
    if (typeof x[field] !== "string") throw new BrainError(`Invalid ${field}`);
  }
  if (!(x.title as string).trim() || (x.title as string).length > 150) throw new BrainError("Title must have 1-150 characters");
  if ((x.summary as string).length > 1200 || (x.content as string).length > 100000) throw new BrainError("Record text too long");
  if (!Array.isArray(x.tags) || x.tags.length > 24 || !x.tags.every(t => typeof t === "string" && t.length < 80)) throw new BrainError("Invalid tags");
  if (typeof x.priority !== "number" || !Number.isInteger(x.priority) || x.priority < 0 || x.priority > 100) throw new BrainError("Priority must be 0-100");
  if (!["active", "draft", "archived"].includes(String(x.status))) throw new BrainError("Invalid status");
  if (!Array.isArray(x.checks) || x.checks.length > 30) throw new BrainError("Invalid review checks");
  const checks: TestRule[] = [];
  for (const c of x.checks) {
    if (!c || typeof c !== "object" || !["contains", "not_contains", "max_length", "min_length"].includes(c.type) ||
       !(typeof c.value === "string" || typeof c.value === "number")) throw new BrainError("Invalid review check");
    checks.push({ type: c.type, value: c.value, label: typeof c.label === "string" ? c.label.slice(0, 200) : undefined });
  }
  let backend = null;
  if (x.kind === "tool" && x.backend !== null && x.backend !== undefined) {
    const b = x.backend as Record<string, unknown>;
    if (typeof b.command !== "string" || !b.command.trim() || !Array.isArray(b.args) || !b.args.every(v => typeof v === "string") ||
      typeof b.toolName !== "string" || typeof b.enabled !== "boolean") throw new BrainError("Invalid MCP backend configuration");
    if (b.args.length > 30 || b.args.some((v: string) => v.length > 500)) throw new BrainError("Tool arguments too long");
    backend = { command: b.command, args: b.args, toolName: b.toolName, enabled: b.enabled, timeoutMs: Math.min(120000, Math.max(1000, Number(b.timeoutMs) || 30000)) };
  }
  return { kind: x.kind, domain: x.domain, title: String(x.title).trim(), summary: String(x.summary), content: String(x.content), tags: x.tags as string[],
    priority: x.priority as number, status: x.status as RecordInput["status"], checks, backend };
}
function tokenize(s: string): string[] { return [...new Set(s.toLowerCase().normalize("NFKD").split(/[^\p{L}\p{N}]+/u).filter(t => t.length > 1))]; }
export function rankRecord(record: BrainRecord, query: string): number {
  if (!query.trim()) return record.priority / 20;
  const terms = tokenize(query);
  const title = record.title.toLowerCase(); const tags = record.tags.join(" ").toLowerCase();
  const summary = record.summary.toLowerCase(); const content = record.content.toLowerCase();
  return terms.reduce((sum, t) => sum + (title.includes(t) ? 8 : 0) + (tags.includes(t) ? 6 : 0) + (summary.includes(t) ? 3 : 0) + (content.includes(t) ? 1 : 0), 0);
}

export class BrainDB {
  db: DatabaseSync;
  constructor(filePath: string = dbPath()) {
    mkdirSync(dirname(filePath), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(filePath);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS records (id TEXT PRIMARY KEY, snapshot TEXT NOT NULL, kind TEXT NOT NULL, domain TEXT NOT NULL, status TEXT NOT NULL, version INTEGER NOT NULL, updated_at TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS records_filter ON records(kind, domain, status);
      CREATE TABLE IF NOT EXISTS revisions (id TEXT PRIMARY KEY, record_id TEXT NOT NULL, version INTEGER NOT NULL, action TEXT NOT NULL, snapshot TEXT NOT NULL, at TEXT NOT NULL, UNIQUE(record_id,version));
      CREATE TABLE IF NOT EXISTS feedback (id TEXT PRIMARY KEY, record_id TEXT, rating TEXT NOT NULL, note TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS audit (id TEXT PRIMARY KEY, action TEXT NOT NULL, target TEXT NOT NULL, created_at TEXT NOT NULL, detail TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS trace_events (
        id TEXT PRIMARY KEY, occurred_at TEXT NOT NULL, run_id TEXT NOT NULL,
        agent TEXT NOT NULL, channel TEXT NOT NULL, event_type TEXT NOT NULL,
        outcome TEXT NOT NULL, record_ids TEXT NOT NULL, record_versions TEXT NOT NULL DEFAULT '{}', metadata TEXT NOT NULL, demo INTEGER NOT NULL DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS trace_by_time ON trace_events(occurred_at DESC);
      CREATE INDEX IF NOT EXISTS trace_by_run ON trace_events(run_id, occurred_at);
    `);
    try { chmodSync(filePath, 0o600); } catch { /* permission may be managed by filesystem */ }
  }
  close() { this.db.close(); }
  private parse(snapshot: string) { return JSON.parse(snapshot) as BrainRecord; }
  get(id: string): BrainRecord | null {
    const row = this.db.prepare("SELECT snapshot FROM records WHERE id = ?").get(id) as {snapshot: string} | undefined;
    return row ? this.parse(row.snapshot) : null;
  }
  list(filter: { kind?: Kind; domain?: Domain; status?: string; query?: string; limit?: number } = {}): BrainRecord[] {
    let sql = "SELECT snapshot FROM records WHERE 1=1"; const args: string[] = [];
    if (filter.kind) { sql += " AND kind=?"; args.push(filter.kind); }
    if (filter.domain) { sql += " AND domain=?"; args.push(filter.domain); }
    if (filter.status) { sql += " AND status=?"; args.push(filter.status); }
    const rows = this.db.prepare(sql).all(...args) as {snapshot:string}[];
    const query = String(filter.query || "");
    const list = rows.map(r => this.parse(r.snapshot)).map(r => ({r,score:rankRecord(r,query)}));
    list.sort((a,b) => (query ? b.score - a.score : b.r.priority - a.r.priority) || b.r.priority - a.r.priority || b.r.updatedAt.localeCompare(a.r.updatedAt));
    return list.filter(v => !query || v.score > 0).slice(0, Math.min(300, Math.max(1, filter.limit ?? 100))).map(v => v.r);
  }
  summary() {
    const all = this.list({limit:300});
    const counts = Object.fromEntries(["preference","skill","example","review","tool"].map(k => [k, all.filter(r => r.kind === k && r.status === "active").length]));
    return { counts, domains: DOMAINS, total: all.length, revisions: (this.db.prepare("SELECT count(*) AS n FROM revisions").get() as {n:number}).n,
      feedback: (this.db.prepare("SELECT count(*) AS n FROM feedback").get() as {n:number}).n };
  }
  private transaction<T>(cb: () => T): T {
    this.db.exec("BEGIN IMMEDIATE");
    try { const result = cb(); this.db.exec("COMMIT"); return result; }
    catch (e) { this.db.exec("ROLLBACK"); throw e; }
  }
  create(raw: unknown): BrainRecord {
    const input = checkInput(raw); const now = new Date().toISOString();
    const rec: BrainRecord = { ...input, id: randomUUID(), version: 1, createdAt: now, updatedAt: now };
    this.transaction(() => this.write(rec,"create")); return rec;
  }
  update(id: string, raw: unknown, expectedVersion: number): BrainRecord {
    return this.transaction(() => {
      const prev = this.get(id);
      if (!prev) throw new BrainError("Record not found", "NOT_FOUND", 404);
      if (prev.version !== expectedVersion) throw new BrainError("Version conflict. Refresh and try again.", "CONFLICT", 409);
      const input = checkInput(raw); const rec: BrainRecord = {...prev,...input,version:prev.version+1,updatedAt:new Date().toISOString()};
      this.write(rec,"update"); return rec;
    });
  }
  restore(id: string, targetVersion: number, expectedVersion: number): BrainRecord {
    return this.transaction(() => {
      const prev = this.get(id);
      if (!prev) throw new BrainError("Record not found", "NOT_FOUND", 404);
      if (prev.version !== expectedVersion) throw new BrainError("Version conflict", "CONFLICT", 409);
      const row = this.db.prepare("SELECT snapshot FROM revisions WHERE record_id=? AND version=?").get(id,targetVersion) as {snapshot:string}|undefined;
      if (!row) throw new BrainError("Revision not found", "NOT_FOUND", 404);
      const historical = this.parse(row.snapshot); const rec: BrainRecord = {...prev, ...checkInput(historical), version: prev.version+1, updatedAt:new Date().toISOString()};
      this.write(rec,"restore"); return rec;
    });
  }
  private write(rec: BrainRecord,action: Revision["action"]) {
    const snapshot = JSON.stringify(rec);
    this.db.prepare(`INSERT INTO records(id,snapshot,kind,domain,status,version,updated_at) VALUES(?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET snapshot=excluded.snapshot,kind=excluded.kind,domain=excluded.domain,status=excluded.status,version=excluded.version,updated_at=excluded.updated_at`).run(
      rec.id,snapshot,rec.kind,rec.domain,rec.status,rec.version,rec.updatedAt);
    this.db.prepare("INSERT INTO revisions(id,record_id,version,action,snapshot,at) VALUES(?,?,?,?,?,?)")
      .run(randomUUID(),rec.id,rec.version,action,snapshot,rec.updatedAt);
    this.audit(action,rec.id,`v${rec.version}`);
  }
  history(id:string): Revision[] {
    return (this.db.prepare("SELECT id,record_id,version,action,snapshot,at FROM revisions WHERE record_id=? ORDER BY version DESC").all(id) as Array<{id:string,record_id:string,version:number,action:Revision["action"],snapshot:string,at:string}>).map(r=>({id:r.id,recordId:r.record_id,version:r.version,action:r.action,snapshot:this.parse(r.snapshot),at:r.at}));
  }
  addFeedback(input:{ recordId?:string|null; rating:string; note:string }): Feedback {
    if (!["accepted","rejected","correction"].includes(input.rating)) throw new BrainError("Invalid rating");
    if (!input.note || input.note.length > 10000) throw new BrainError("Feedback note required, max 10000 characters");
    if (input.recordId && !this.get(input.recordId)) throw new BrainError("Referenced record not found", "NOT_FOUND",404);
    const f:Feedback = {id:randomUUID(),recordId:input.recordId||null,rating:input.rating as Feedback["rating"],note:input.note,createdAt:new Date().toISOString()};
    this.db.prepare("INSERT INTO feedback(id,record_id,rating,note,created_at) VALUES(?,?,?,?,?)").run(f.id,f.recordId,f.rating,f.note,f.createdAt);
    this.audit("feedback",f.recordId||"general",f.rating); return f;
  }
  listFeedback(): Feedback[] { return (this.db.prepare("SELECT id,record_id AS recordId,rating,note,created_at AS createdAt FROM feedback ORDER BY created_at DESC LIMIT 200").all() as Feedback[]); }
  private audit(action:string,target:string,detail:string) { this.db.prepare("INSERT INTO audit(id,action,target,created_at,detail) VALUES(?,?,?,?,?)").run(randomUUID(),action,target,new Date().toISOString(),detail); }
  auditLog() { return this.db.prepare("SELECT action,target,created_at AS createdAt,detail FROM audit ORDER BY created_at DESC LIMIT 100").all(); }
  /** Stable private digest for correlating repeated prompts without storing their text. */
  fingerprint(value:string) {
    let row=this.db.prepare("SELECT value FROM meta WHERE key='trace_hmac_secret'").get() as {value:string}|undefined;
    if(!row) {
      this.db.prepare("INSERT OR IGNORE INTO meta(key,value) VALUES ('trace_hmac_secret',?)").run(randomBytes(32).toString("hex"));
      row=this.db.prepare("SELECT value FROM meta WHERE key='trace_hmac_secret'").get() as {value:string};
    }
    return createHmac("sha256",Buffer.from(row.value,"hex")).update(value).digest("hex").slice(0,16);
  }
  /** Telemetry stores metadata only; never store full prompts, generated content or tool parameters. */
  trace(event: {
    agent: string; channel: string; eventType: string; outcome?: string;
    runId?: string | null; recordIds?: string[]; recordVersions?: Record<string,number>; metadata?: Record<string, unknown>; demo?: boolean;
  }) {
    const safe = (value:unknown, limit=160) => String(value ?? "").slice(0, limit);
    const allowed = ["claude", "codex", "unknown", "web", "test"];
    const agent = allowed.includes(event.agent) ? event.agent : "unknown";
    const runId = safe(event.runId || `${agent}:${event.channel}:unlinked`, 180);
    // Whitelist metadata keys. These are counters, fingerprints and identifiers only.
    const safeMetadata: Record<string, string | number | boolean | null> = {};
    for (const [key, value] of Object.entries(event.metadata || {})) {
      if (!/^(client|domain|count|recordCount|contextChars|promptChars|promptHash|matchedDomains|resultCount|checkCount|passed|step|note|tool|version|sessionLinked|origin|tested)$/i.test(key)) continue;
      if (["string", "number", "boolean"].includes(typeof value) || value === null) {
        safeMetadata[key] = typeof value === "string" ? safe(value, 160) : value as number | boolean | null;
      }
    }
    const item = {
      id: randomUUID(), occurredAt: new Date().toISOString(), runId,
      agent, channel: safe(event.channel, 50), eventType: safe(event.eventType, 80),
      outcome: safe(event.outcome || "observed", 24),
      recordIds: (event.recordIds || []).filter(x=>/^[a-f0-9-]{36}$/i.test(x)).slice(0,40),
      recordVersions:Object.fromEntries(Object.entries(event.recordVersions||{}).filter(([id,v])=>/^[a-f0-9-]{36}$/i.test(id)&&Number.isInteger(v)&&v>0).slice(0,40)),
      metadata: safeMetadata, demo: !!event.demo
    };
    this.db.prepare(`INSERT INTO trace_events(id,occurred_at,run_id,agent,channel,event_type,outcome,record_ids,record_versions,metadata,demo) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
      .run(item.id,item.occurredAt,item.runId,item.agent,item.channel,item.eventType,item.outcome,JSON.stringify(item.recordIds),JSON.stringify(item.recordVersions),JSON.stringify(item.metadata),item.demo?1:0);
    return item;
  }
  listTrace(filter:{agent?:string;channel?:string;recordId?:string;includeDemo?:boolean;limit?:number}={}) {
    const filters:string[]=[]; const args:(string|number)[]=[];
    if(!filter.includeDemo){filters.push("demo = 0");}
    if(filter.agent && filter.agent!=="all"){filters.push("agent=?");args.push(filter.agent);}
    if(filter.channel && filter.channel!=="all"){filters.push("channel=?");args.push(filter.channel);}
    if(filter.recordId){filters.push("instr(record_ids,?) > 0");args.push(JSON.stringify(filter.recordId).slice(1,-1));}
    args.push(Math.min(500,Math.max(1,Number(filter.limit)||150)));
    const where=filters.length?" WHERE "+filters.join(" AND "):"";
    const rows=this.db.prepare(`SELECT id,occurred_at AS occurredAt,run_id AS runId,agent,channel,event_type AS eventType,outcome,record_ids AS recordIds,record_versions AS recordVersions,metadata,demo FROM trace_events${where} ORDER BY occurred_at DESC,rowid DESC LIMIT ?`).all(...args) as Array<{recordIds:string;recordVersions:string;metadata:string;demo:number}>;
    return rows.map(r=>({...r,recordIds:JSON.parse(r.recordIds) as string[],recordVersions:JSON.parse(r.recordVersions) as Record<string,number>,metadata:JSON.parse(r.metadata) as Record<string,unknown>,demo:!!r.demo}));
  }
  traceStats() {
    const rows=this.db.prepare(`SELECT event_type AS name,COUNT(*) AS count FROM trace_events WHERE demo=0 GROUP BY event_type ORDER BY count DESC`).all() as {name:string,count:number}[];
    const get=(name:string)=>rows.find(r=>r.name===name)?.count||0;
    return {events:rows.reduce((n,r)=>n+r.count,0),byEvent:rows,
      startup: get("hook.session.context"),promptMatches:get("hook.prompt.context"),
      discovery:get("mcp.brain_discover"),retrieval:get("mcp.brain_get"),
      reviews:get("mcp.brain_review"),feedback:get("mcp.brain_feedback"),
      note:"Observed calls and delivered instructions are not proof the agent followed them. Artifact quality must be evaluated separately."};
  }
  seedTraceDemo() {
    if((this.db.prepare("SELECT COUNT(*) AS n FROM trace_events WHERE demo=1").get() as {n:number}).n) return 0;
    const diagram = this.list({kind:"skill",status:"active"}).find(r=>r.domain==="diagrams");
    const style = this.list({kind:"preference",status:"active"}).find(r=>r.domain==="diagrams");
    const writing = this.list({kind:"skill",status:"active"}).find(r=>r.domain==="writing");
    const runs=[
      {agent:"claude",runId:"demo-claude-drawing",stages:[
        ["hook","hook.session.context","delivered",[],"Global working style loaded"],
        ["hook","hook.prompt.context","delivered",[diagram?.id,style?.id],"Drawing instructions matched"],
        ["mcp","mcp.brain_discover","success",[diagram?.id,style?.id],"Skill catalog searched"],
        ["mcp","mcp.brain_get","success",[diagram?.id],"Full drawing skill retrieved"],
        ["mcp","mcp.brain_review","success",[diagram?.id],"Example review submitted"]
      ]},
      {agent:"codex",runId:"demo-codex-writing",stages:[
        ["hook","hook.session.context","delivered",[],"Global working style loaded"],
        ["hook","hook.prompt.context","delivered",[writing?.id],"Writing procedure matched"],
        ["mcp","mcp.brain_discover","success",[writing?.id],"Document skills searched"],
        ["mcp","mcp.brain_get","success",[writing?.id],"Writing procedure retrieved"]
      ]}
    ] as const;
    let count=0;
    for(const run of runs) for(const [channel,eventType,outcome,ids,note] of run.stages) {
      this.trace({agent:run.agent,runId:run.runId,channel,eventType,outcome,recordIds:ids.filter((x):x is string=>!!x),recordVersions:Object.fromEntries(ids.filter((x):x is string=>!!x).map(id=>[id,this.get(id)?.version||1])),metadata:{note,origin:"demonstration"},demo:true});count++;
    }
    return count;
  }
  clearTraceDemo() {return this.db.prepare("DELETE FROM trace_events WHERE demo=1").run().changes;}
  bootstrapWithRecords(maxChars=3500) {
    const items = this.list({ kind:"preference",status:"active" }).slice(0,35);
    const included:BrainRecord[]=[];
    let out = "PERSONAL BRAIN STYLE BASELINE\nThese are personal working preferences, not project facts. Use brain_discover for specialized skills.\n";
    for (const item of items) {
      const line = `\n[${item.domain}] ${item.title}: ${item.content.replace(/\s+/g," ").slice(0,380)}\n`;
      if (out.length + line.length > maxChars) break;
      out += line;included.push(item);
    }
    return {text:out,records:included};
  }
  bootstrap(maxChars=3500) { return this.bootstrapWithRecords(maxChars).text; }
  discover(task:string,kinds:Kind[]=["skill","preference","tool","review","example"],limit=12) {
    return this.list({ status:"active",query:task,limit:300 }).filter(r=>kinds.includes(r.kind)).slice(0,Math.max(1,Math.min(30,limit))).map(r=>({id:r.id,kind:r.kind,domain:r.domain,title:r.title,summary:r.summary,tags:r.tags,version:r.version,priority:r.priority,invokable:r.kind==="tool" && !!r.backend?.enabled}));
  }
  evaluate(content:string,domain:Domain="general") {
    const rules = this.list({kind:"review",status:"active"}).filter(r=>r.domain==="general" || r.domain===domain);
    const findings:{ruleId:string,check:string,passed:boolean,detail:string}[]=[];
    let manual=0;
    for(const rule of rules) {
      if(!rule.checks.length) { manual++;continue; }
      for(const check of rule.checks) {
        const v=String(check.value);
        let passed = false;
        if(check.type==="contains") passed=content.toLowerCase().includes(v.toLowerCase());
        if(check.type==="not_contains") passed=!content.toLowerCase().includes(v.toLowerCase());
        if(check.type==="min_length") passed=content.length>=Number(v);
        if(check.type==="max_length") passed=content.length<=Number(v);
        findings.push({ruleId:rule.id,check:check.label||`${check.type} ${v}`,passed,detail:passed?"Check passed":"Check failed"});
      }
    }
    return { passed:findings.every(x=>x.passed), automated:findings.length, manualReviewRules:manual, findings,
      note:"Text checks are deterministic. Visual layout and architectural correctness still require separate validation." };
  }
}
