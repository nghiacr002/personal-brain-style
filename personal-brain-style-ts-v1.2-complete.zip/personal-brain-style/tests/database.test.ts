import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BrainDB } from "../src/database.ts";
import { seed } from "../src/seed.ts";
import type { RecordInput } from "../src/models.ts";

const fixture = ():RecordInput=>({kind:"preference",domain:"diagrams",title:"Personal diagram convention",summary:"Short description",content:"Prefer orthogonal routing",tags:["diagram","drawio"],priority:90,status:"active",checks:[],backend:null});
function withDb<T>(cb:(db:BrainDB)=>T):T{const dir=mkdtempSync(join(tmpdir(),"pb-test-"));const db=new BrainDB(join(dir,"brain.sqlite"));try{return cb(db);}finally{db.close();rmSync(dir,{recursive:true,force:true});}}

test("persistent SQLite store survives reopening",()=>{
  const dir=mkdtempSync(join(tmpdir(),"pb-persist-")); const file=join(dir,"brain.sqlite");
  try{const db=new BrainDB(file);const r=db.create(fixture());db.close();const db2=new BrainDB(file);assert.equal(db2.get(r.id)?.content,"Prefer orthogonal routing");db2.close();}finally{rmSync(dir,{recursive:true,force:true});}
});
test("version history and rollback preserve all snapshots",()=>withDb(db=>{
  const r=db.create(fixture()); const next=db.update(r.id,{...fixture(),content:"Use pastel color groups"},1);
  assert.equal(next.version,2);
  assert.throws(()=>db.update(r.id,fixture(),1),{code:"CONFLICT"});
  const restored=db.restore(r.id,1,2);
  assert.equal(restored.version,3);assert.equal(restored.content,"Prefer orthogonal routing");
  assert.deepEqual(db.history(r.id).map(h=>h.version),[3,2,1]);
}));
test("invalid records and tool metadata are rejected",()=>withDb(db=>{
  assert.throws(()=>db.create({...fixture(),kind:"project-memory"}));
  assert.throws(()=>db.create({...fixture(),backend:{command:"sh",args:[],toolName:"bad",enabled:true},kind:"tool",title:""}));
  assert.throws(()=>db.create({...fixture(),checks:[{type:"eval",value:"x"}]}));
}));
test("global-only memory: discovery returns relevant skills without project store",()=>withDb(db=>{
  seed(db);const hits=db.discover("drawio architecture diagrams",undefined,10);
  assert.ok(hits.some(h=>h.title.includes("editable system diagram")));
  assert.ok(hits.every(h=>["skill","preference","tool","review","example"].includes(h.kind)));
  assert.ok(!Object.keys(db.summary()).includes("projects"));
  assert.equal(db.discover("xylophonetextthatdoesnotmatch",undefined,10).length,0);
}));
test("feedback records corrections without changing active rules",()=>withDb(db=>{
  const r=db.create(fixture()); const fb=db.addFeedback({recordId:r.id,rating:"correction",note:"Less line crossing"});
  assert.equal(fb.rating,"correction"); assert.equal(db.get(r.id)?.version,1);
  assert.equal(db.listFeedback().length,1);
}));
test("review checks produce pass/fail and manual counts",()=>withDb(db=>{
  seed(db);
  assert.equal(db.evaluate("The document contains TBD","writing").passed,false);
  assert.equal(db.evaluate("All sections complete","writing").passed,true);
  assert.ok(db.evaluate("diagram sample","diagrams").manualReviewRules>=1);
}));
test("seed operation is idempotent",()=>withDb(db=>{
  assert.ok(seed(db)>0);assert.equal(seed(db),0);
}));
