import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { BrainDB } from "../src/database.ts";
import { seed } from "../src/seed.ts";

const app=resolve("src/cli.ts");const runner=resolve("scripts/run.mjs");
test("MCP stdio initialization, discovery, resources and prompts",{timeout:12000},async()=>{
  const dir=mkdtempSync(join(tmpdir(),"pb-mcp-"));const db=new BrainDB(join(dir,"brain.sqlite"));seed(db);db.close();
  const child=spawn(process.execPath,[runner,app,"mcp"],{cwd:resolve("."),env:{...process.env,PB_HOME:dir},stdio:["pipe","pipe","pipe"]});
  let buffer="";let waiter=new Map<number,(x:any)=>void>();let stderr="";
  child.stderr.on("data",chunk=>stderr+=chunk.toString());
  child.stdout.on("data",chunk=>{buffer+=chunk.toString();let i;while((i=buffer.indexOf("\n"))>=0){const line=buffer.slice(0,i);buffer=buffer.slice(i+1);if(!line.trim())continue;const msg=JSON.parse(line);waiter.get(msg.id)?.(msg);waiter.delete(msg.id);}});
  let id=0;
  function call(method:string,params:any={}) { const reqId=++id;return new Promise<any>((done,reject)=>{
    const timeout=setTimeout(()=>reject(new Error(`MCP response timeout ${method}: ${stderr}`)),5000);
    waiter.set(reqId,msg=>{clearTimeout(timeout);done(msg);});
    child.stdin.write(JSON.stringify({jsonrpc:"2.0",id:reqId,method,params})+"\n");
  });}
  try{
    const init=await call("initialize",{protocolVersion:"2025-11-25",capabilities:{},clientInfo:{name:"test",version:"0"}});
    assert.equal(init.result.serverInfo.name,"personal-brain-style");
    child.stdin.write(JSON.stringify({jsonrpc:"2.0",method:"notifications/initialized"})+"\n");
    const list=await call("tools/list");
    assert.ok(list.result.tools.some((t:any)=>t.name==="brain_discover"));
    const search=await call("tools/call",{name:"brain_discover",arguments:{task:"drawio architecture"}});
    const matching=JSON.parse(search.result.content[0].text);
    assert.ok(matching.some((x:any)=>x.kind==="skill"));
    const resource=await call("resources/read",{uri:"brain://style/baseline"});
    assert.match(resource.result.contents[0].text,/PERSONAL BRAIN STYLE BASELINE/);
    const prompts=await call("prompts/list");assert.equal(prompts.result.prompts[0].name,"personalized_task");
    const missing=await call("tools/call",{name:"brain_get",arguments:{id:"missing"}});
    assert.equal(missing.result.isError,true);
  }finally{child.stdin.end();child.kill();rmSync(dir,{recursive:true,force:true});}
});
