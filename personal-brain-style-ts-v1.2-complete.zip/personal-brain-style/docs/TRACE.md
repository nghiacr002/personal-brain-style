# Trace Explorer — Operational guide

Trace Explorer tracks **how Personal Brain was invoked**. It is not a model internals debugger.

## Event sources

| Source | Event | What it proves |
|---|---|---|
| Claude/Codex hook | `hook.session.context` | A startup hook produced global style JSON |
| Claude/Codex hook | `hook.prompt.context` | A prompt hook produced matching skill/style JSON |
| Claude/Codex hook | `hook.prompt.no_match` | A prompt hook ran without matching a domain |
| MCP connection | `mcp.initialize` | A compatible MCP client initialized a server process |
| MCP tool registry | `mcp.tools.list` | The client requested the tool list |
| MCP tool | `mcp.brain_discover` | The client searched the style/skill catalog |
| MCP tool | `mcp.brain_get` | The client requested full contents of a specific record |
| MCP tool | `mcp.brain_review` | The client submitted text for automated review checks |
| MCP tool | `mcp.brain_feedback` | The client recorded feedback |
| MCP tool | `mcp.brain_call_tool` | The client attempted a configured external tool invocation |

All MCP calls are recorded with success/error, time, agent hint, and available record IDs and versions. The command-line arguments used to register MCP (`mcp claude`, `mcp codex`) identify the agent; unknown clients appear as `unknown`. The registration hint identifies the originating connection, **not a security boundary**.

## How to reverse trace a drawing instruction

1. Open **Trace Explorer**.
2. In **Reverse by rule**, select `Editable draw.io architecture style`.
3. Filter by `claude` or `codex`.
4. Inspect `hook.prompt.context` to see whether the matching rule ID and version were emitted.
5. Inspect `mcp.brain_discover` and `mcp.brain_get` to see whether the agent actively searched and retrieved a skill.
6. Inspect `mcp.brain_review` to see whether a deterministic text validation was requested.
7. Judge actual output quality separately from an artifact and acceptance criteria.

**Important:** CLI session-start hooks and MCP server calls often run in different processes. The hook may provide a session ID, but MCP stdio clients do not necessarily provide the same ID. `runId` values are therefore not guaranteed to correlate. Use agent, timestamps and record IDs for investigation; do not claim exact end-to-end tracing when IDs are missing.

## Evidence interpretation

- Hook **emitted**: Our process wrote context as a hook response. The host may still reject or ignore it. Do not interpret as confirmed model compliance.
- MCP **retrieved**: The client requested the full record and the server responded. This does not prove the model obeyed it.
- Review **called**: The server executed supported text checks; manual/visual checks remain unverified.
- Real **effectiveness**: Requires comparing the generated artifact to measurable criteria, or collecting independent human acceptance evidence.

The dashboard's live counters exclude demonstration events. You can add synthetic examples in **Generate sample traces** and remove them later; they are labeled `DEMO ONLY`.

## Privacy and storage

Trace records live in the same local SQLite file as the style catalog (`~/.personal-brain-style/brain.sqlite` by default). Each trace row stores:

- Timestamp, channel, event name, result, agent hint, run ID.
- Matched style/skill record IDs and their version at invocation time.
- Small whitelisted metadata counters and a **keyed HMAC fingerprint** of hook prompts.

It does **not** store original prompts, tool-call arguments, agent output, external tool responses, or full project knowledge. A session identifier supplied by a CLI can still reveal a stable ID, so handle database exports with care. Back up or delete the SQLite file with normal filesystem controls.

## CLI

```bash
npm run cli -- trace stats
npm run cli -- trace demo
npm run cli -- trace export
npm run cli -- trace export --demo
npm run cli -- trace clear-demo
```

## API

All HTTP API endpoints require the local Bearer token and pass the origin check:

- `GET /api/trace/stats`
- `GET /api/trace?agent=claude&channel=hook&recordId=<uuid>&demo=1`
- `POST /api/trace/demo`
- `DELETE /api/trace/demo`

## Limits

- This is a local developer tool, not a network-exposed observability service.
- No durable trace retention policy, encryption-at-rest, or enterprise authentication is included.
- No actual diagram renderer or image-diff engine is built into v1.2.
- Trace data alone is insufficient to calculate instruction effectiveness; use controlled artifact comparisons and review feedback.
