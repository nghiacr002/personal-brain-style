import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { readFileSync, existsSync } from "node:fs";
import { dirname, join, extname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { timingSafeEqual } from "node:crypto";
import { BrainDB } from "./database.ts";
import { seed } from "./seed.ts";
import { manageHookConfig } from "./hook-install.ts";
import { BrainError, DOMAINS, KINDS, type Domain, type Kind } from "./models.ts";

const publicDir=resolve(dirname(fileURLToPath(import.meta.url)),"../public");
function json(res:ServerResponse,status:number,payload:unknown) { const data=JSON.stringify(payload);res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});res.end(data); }
function authorized(req:IncomingMessage,token:string) {
  const provided=(req.headers.authorization||"").replace(/^Bearer\s+/i,"") || String(req.headers["x-brain-token"]||"");
  const a=Buffer.from(provided), b=Buffer.from(token);
  return a.length===b.length && timingSafeEqual(a,b);
}
async function body(req:IncomingMessage):Promise<any> {
  let data="";
  for await (const chunk of req) {data+=chunk;if(data.length>180000)throw new BrainError("Request too large","TOO_LARGE",413);}
  if(!data.trim())return {};
  try {return JSON.parse(data);}catch{throw new BrainError("Invalid JSON");}
}
function allowOrigin(req:IncomingMessage) {
  const origin=req.headers.origin;
  if(!origin)return true;
  try {const parsed=new URL(origin);return parsed.hostname==="127.0.0.1" && parsed.protocol==="http:";}catch{return false;}
}
export function createBrainHttpServer(db:BrainDB,token:string) {
  return createServer(async (req,res)=>{
    res.setHeader("X-Frame-Options","DENY");
    res.setHeader("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
    res.setHeader("Referrer-Policy","no-referrer");
    const method=req.method||"GET";
    try {
      const url=new URL(req.url||"/","http://127.0.0.1");const path=url.pathname;
      if(path.startsWith("/api/")) {
        if(!authorized(req,token))return json(res,401,{error:"AUTH_REQUIRED",message:"Set the access token from your Terminal"});
        if(!allowOrigin(req))return json(res,403,{error:"INVALID_ORIGIN"});
        if(path==="/api/summary"&&method==="GET")return json(res,200,db.summary());
        if(path==="/api/examples/seed"&&method==="POST")return json(res,200,{created:seed(db),summary:db.summary()});
        if(path==="/api/trace/stats"&&method==="GET")return json(res,200,db.traceStats());
        if(path==="/api/trace"&&method==="GET")return json(res,200,db.listTrace({
          agent:url.searchParams.get("agent")||undefined,
          channel:url.searchParams.get("channel")||undefined,
          recordId:url.searchParams.get("recordId")||undefined,
          includeDemo:url.searchParams.get("demo")==="1",
          limit:Math.min(500,Math.max(1,Number(url.searchParams.get("limit")||150)))
        }));
        if(path==="/api/trace/demo"&&method==="POST")return json(res,200,{created:db.seedTraceDemo()});
        if(path==="/api/trace/demo"&&method==="DELETE")return json(res,200,{removed:db.clearTraceDemo()});
        if(path==="/api/activation"&&method==="GET")return json(res,200,{claude:manageHookConfig("status","claude"),codex:manageHookConfig("status","codex")});
        if(path==="/api/items"&&method==="GET") {
          const k=url.searchParams.get("kind");const d=url.searchParams.get("domain");
          return json(res,200,db.list({kind:KINDS.includes(k as Kind)?k as Kind:undefined,domain:DOMAINS.includes(d as Domain)?d as Domain:undefined,
            status:url.searchParams.get("status")||undefined,query:url.searchParams.get("q")||undefined,limit:300}));
        }
        if(path==="/api/items"&&method==="POST")return json(res,201,db.create(await body(req)));
        const item=path.match(/^\/api\/items\/([a-f0-9-]{36})$/);
        if(item && method==="GET") {const found=db.get(item[1]);return found?json(res,200,found):json(res,404,{error:"NOT_FOUND"});}
        if(item && method==="PUT") {const x=await body(req);return json(res,200,db.update(item[1],x.record,Number(x.expectedVersion)));}
        const history=path.match(/^\/api\/items\/([a-f0-9-]{36})\/history$/);
        if(history&&method==="GET")return json(res,200,db.history(history[1]));
        const restore=path.match(/^\/api\/items\/([a-f0-9-]{36})\/restore$/);
        if(restore&&method==="POST") {const x=await body(req);return json(res,200,db.restore(restore[1],Number(x.version),Number(x.expectedVersion)));}
        if(path==="/api/bootstrap"&&method==="GET")return json(res,200,{text:db.bootstrap()});
        if(path==="/api/discover"&&method==="GET")return json(res,200,db.discover(url.searchParams.get("q")||"",undefined,24));
        if(path==="/api/review"&&method==="POST") {const x=await body(req);return json(res,200,db.evaluate(String(x.content||""),DOMAINS.includes(x.domain)?x.domain:"general"));}
        if(path==="/api/feedback"&&method==="GET")return json(res,200,db.listFeedback());
        if(path==="/api/feedback"&&method==="POST")return json(res,201,db.addFeedback(await body(req)));
        if(path==="/api/audit"&&method==="GET")return json(res,200,db.auditLog());
        return json(res,404,{error:"NOT_FOUND"});
      }
      if(method!=="GET")return json(res,405,{error:"METHOD_NOT_ALLOWED"});
      const route=path==="/"?"/index.html":path;
      if(!["/index.html","/app.js","/style.css"].includes(route))return json(res,404,{error:"NOT_FOUND"});
      const file=join(publicDir,route.slice(1));if(!existsSync(file))return json(res,404,{error:"NOT_FOUND"});
      const mime:Record<string,string>={".html":"text/html; charset=utf-8",".js":"application/javascript; charset=utf-8",".css":"text/css; charset=utf-8"};
      res.writeHead(200,{"Content-Type":mime[extname(file)]||"application/octet-stream","Cache-Control":"no-store"});res.end(readFileSync(file));
    }catch(error){const code=error instanceof BrainError?error.status:500;return json(res,code,{error:error instanceof BrainError?error.code:"SERVER_ERROR",message:error instanceof Error?error.message:"Unknown error"});}
  });
}
