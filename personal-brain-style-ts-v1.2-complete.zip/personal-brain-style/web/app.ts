type Kind="preference"|"skill"|"example"|"review"|"tool";
type View=Kind|"overview"|"discover"|"feedback"|"history"|"activation"|"trace";
type RecordItem={id:string;kind:Kind;domain:string;title:string;summary:string;content:string;tags:string[];priority:number;status:string;version:number;updatedAt:string;createdAt:string;checks:unknown[];backend:unknown};
type Summary={total:number;revisions:number;feedback:number;counts:Record<Kind,number>};
const $=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const main=$("main"),editor=$("editor") as HTMLDialogElement,revisions=$("revisions") as HTMLDialogElement;
const labels:Record<string,string>={overview:"Overview",preference:"My Preferences",skill:"Skills",example:"Approved Examples",review:"Review Standards",tool:"MCP Tool Catalog",discover:"Discovery Lab",feedback:"Feedback",history:"Activity",activation:"Auto Activation",trace:"Trace Explorer"};
const icons:Record<string,string>={preference:"✦",skill:"▦",example:"◈",review:"✓",tool:"⛓"};
let active:View="overview",items:RecordItem[]=[],editing:RecordItem|null=null,token=sessionStorage.getItem("personal-brain-token")||"",search="",domain="all",summary:Summary|null=null;
const esc=(v:unknown)=>String(v??"").replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch]||ch));
const formatTime=(s:string)=>new Date(s).toLocaleString(undefined,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
const ch=(kind:string)=>`<span class="chip ${esc(kind)}">${esc(kind)}</span>`;
const empty=(title:string,desc:string)=>`<div class="empty"><span>◌</span><b>${esc(title)}</b><p>${esc(desc)}</p></div>`;

// Every major feature includes an accessible info button with concrete How / Why guidance.
type Help={what:string;how:string;why:string;limitations:string;example:string};
const HELP:Record<string,Help>={
  overview:{what:"An inventory of personal working methods shared across agent runtimes.",how:"Shows active preferences, skills, examples, checks and recorded revisions. Edit from the library; agents read the latest approved versions.",why:"Keep your personal work style consistent without copying the same instructions into each conversation.",limitations:"The dashboard is not a project-memory manager or an agent-runtime monitor.",example:"Add a global writing rule; both Claude and Codex receive it in subsequent tasks."},
  preference:{what:"Global personal design, thinking and writing preferences.",how:"Store each rule as a versioned record with a domain, tags and priority. Startup and task hooks select relevant rules.",why:"Your work standards become portable between Claude Code and Codex.",limitations:"These rules influence generated output; they cannot force an agent to obey them.",example:"Require compact rounded diagrams with orthogonal connectors."},
  skill:{what:"Step-by-step procedures an agent can discover for a task.",how:"The prompt hook selects matching skills; an MCP agent can search with brain_discover and retrieve full text using brain_get.",why:"Reusable procedures are more reliable and easier to improve than a monolithic prompt.",limitations:"A discovered skill is not evidence of executed steps.",example:"For a diagram, choose a layout, generate draw.io XML and validate it."},
  example:{what:"Reusable reference content demonstrating your preferred format and quality.",how:"Store examples with a domain and searchable tags; agents can request matching examples through MCP.",why:"Concrete examples reduce ambiguity when explaining style.",limitations:"Examples are general templates, never private project facts or automatically rendered artifacts.",example:"An acceptance-criteria template with actors, triggers and results."},
  review:{what:"Your quality criteria, including deterministic text checks and manual rubrics.",how:"Define checks for forbidden/required terms and length. Call brain_review to evaluate provided text. Visual inspections require external rendering.",why:"Detect recurring issues before accepting an output.",limitations:"A text check does not prove diagrams render or architectures are correct.",example:"Reject document placeholders such as TBD; separately inspect visual connector crossings."},
  tool:{what:"A catalog of external MCP capabilities available to your agents.",how:"Store a tool description. An administrator can configure and enable its command and tool name after review. Agents discover, inspect and invoke using MCP.",why:"Agents find the right drawing or document tool without loading every tool's definition.",limitations:"Catalog entries do not install servers. External invocation remains disabled until configured and approved.",example:"Register an approved draw.io MCP for editable diagrams."},
  discover:{what:"A simulator to inspect which styles and skills match a proposed task.",how:"Searches active records and ranks matches. Use the review simulator to test deterministic checks. This runs from the UI, not an agent.",why:"Find missing tags and improve discovery without spending model tokens.",limitations:"UI searches do not prove Claude or Codex called the MCP server.",example:"Search 'draw an architecture diagram' and verify a drawing skill appears."},
  activation:{what:"Automatically supplies personal style to Claude Code and Codex.",how:"SessionStart sends a concise baseline. UserPromptSubmit adds task-specific rules when a prompt matches. MCP remains available for deeper retrieval.",why:"You do not need to type 'load my style' at every new session.",limitations:"Hook installation does not prove a live agent executed the hook. Confirm this in Trace Explorer.",example:"Start Claude, ask to draw a diagram and inspect its recorded hook.prompt.context event."},
  feedback:{what:"Human feedback about accepted work, corrections and rejected output.",how:"Record feedback against a style record or generally; later use it to propose and approve rule revisions.",why:"Prevent the same mistake from repeating across agents.",limitations:"Feedback is not model fine-tuning and does not change active preferences automatically.",example:"Record that a diagram had unnecessary crossing lines; edit the approved diagram rule."},
  history:{what:"An audit trail of style edits, restores and feedback.",how:"Every record edit creates a new immutable revision. Open a record's History to restore an earlier snapshot as a new version.",why:"Make style changes reversible and explainable.",limitations:"The activity log is not agent trace telemetry; use Trace Explorer for live agent events.",example:"Restore version 2 of your writing rules without deleting later history."},
  trace:{what:"Reverse trace of Personal Brain calls made by Claude Code and Codex.",how:"Collects SessionStart and prompt hook deliveries plus MCP initialization, search, get, review and feedback calls. Filter by agent, channel or knowledge record, then inspect which records and versions were delivered.",why:"Understand whether the Brain was contacted, which instructions were emitted and where the process stopped.",limitations:"A delivered instruction is not proof it affected the final answer. MCP processes and hook sessions may not share a correlation ID. Prompts and tool payloads are not stored.",example:"For a draw.io request, confirm hook.prompt.context included your drawing rule; then look for mcp.brain_get or mcp.brain_review."},
  metrics:{what:"Counts derived from recorded agent telemetry.",how:"Only actual hook or MCP events contribute to live metrics; demo events are excluded.",why:"Separate real adoption from simulations.",limitations:"Counts indicate delivery or calls, not response correctness.",example:"A higher brain_get count means more instructions were retrieved, not necessarily followed."},
  library:{what:"Examples for all personal working style domains.",how:"Use the sample library loader to add missing example records. It never replaces titles already present.",why:"Provide concrete starting material for drawing, writing, architecture and review.",limitations:"These are editable examples, not universal rules or project knowledge.",example:"Seed Mermaid syntax guidance, editable draw.io procedures, review rubrics and UI standards."},
  trace_reverse:{what:"Find all observed events that mention one selected knowledge record.",how:"Choose a preference or skill. Trace Explorer filters by its record ID and shows the recorded version used in each event.",why:"Check whether a specific rule was actually delivered or requested over time.",limitations:"An event referencing a rule is not proof the agent complied with it.",example:"Select 'Editable draw.io architecture style' and find relevant Claude and Codex hook deliveries."},
  trace_demo:{what:"Clearly marked synthetic trace walkthroughs.",how:"Create example Claude and Codex timelines, then enable Show demos. Demo events are stored separately from live statistics and may be removed.",why:"Understand trace data before connecting real agents.",limitations:"Demonstrations are not real Claude or Codex activity.",example:"A sample diagram flow shows session hook, task hook, discover, get and review."},
  fields:{what:"The schema for a personal style record.",how:"Type selects skill, preference, example, review or tool. Domain and tags drive retrieval. Priority affects ordering. Status controls agent visibility; saving creates a revision.",why:"Well-structured records improve discovery and allow safe rollback.",limitations:"Do not store passwords or project secrets in personal style records.",example:"Type Skill; domain Diagrams; tags drawio, architecture; priority 95."},
  revision:{what:"Immutable history for a single style record.",how:"Updating or restoring always creates a new version while preserving old snapshots.",why:"You can test improvements and recover a previous style rule.",limitations:"Restoring rules does not undo output already generated by an agent.",example:"Restore a compact layout rule from v2 while keeping v3 and v4 in history."},
  baseline:{what:"Compact global preferences loaded at agent startup.",how:"The bootstrap function selects active preferences up to a safe character limit. Specialized skills stay in the repository and load on demand.",why:"Keep routine context small while preserving essential working standards.",limitations:"Long content may be truncated by the context budget.",example:"The startup summary includes writing style and architectural defaults, but not full drawing procedures."},
  review_simulator:{what:"Test text validation locally before using the rule with an agent.",how:"Paste content, choose a domain and run stored deterministic checks.",why:"See what automated checks can detect and what still needs a human inspection.",limitations:"It is not a full document or diagram renderer.",example:"Paste a BRD containing TBD and inspect the failure."}
};
const infoButton=(key:string)=>`<button type="button" class="info-button" data-info="${esc(key)}" aria-label="About ${esc(labels[key]||key)}" title="How and why this works">i</button>`;
function showHelp(key:string){const entry=HELP[key]||HELP.overview;$("helpTitle").textContent=labels[key]||key.replace(/_/g," ").replace(/\b\w/g,s=>s.toUpperCase());
  $("helpContent").innerHTML=[
    ["What it does",entry.what],["How it works",entry.how],["Why it matters",entry.why],["Example",entry.example],["Limits and evidence",entry.limitations]
  ].map(([title,text])=>`<section class="help-part"><h3>${esc(title)}</h3><p>${esc(text)}</p></section>`).join("");
  ($( "helpDialog") as HTMLDialogElement).showModal();}

let toastTimer:ReturnType<typeof setTimeout>;
function toast(message:string){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3200);}
async function api<T=unknown>(url:string,options:RequestInit={}):Promise<T>{
  const result=await fetch(url,{...options,headers:{Authorization:`Bearer ${token}`,...(options.body?{"Content-Type":"application/json"}:{}),...options.headers}});
  if(!result.ok){let data:{message?:string}={};try{data=await result.json();}catch{}throw new Error(data.message||`Request failed ${result.status}`);}
  return result.json() as Promise<T>;
}
function getToken(){const value=prompt("Enter the access token shown when you start Personal Brain (npm start).",token);
  if(value===null)return;token=value.trim();sessionStorage.setItem("personal-brain-token",token);refresh().catch(e=>toast(e.message));}
function layout(title:string,desc:string,action:string="",body:string=""){
  main.innerHTML=`<div class="hero"><div><div class="eyebrow">PERSONAL STYLE CONTROL PLANE</div><div class="title-with-info"><h1>${esc(title)}</h1>${infoButton(active)}</div><p>${esc(desc)}</p></div>${action}</div>${body}`;
  $("breadcrumb").textContent=title;
}
function card(item:RecordItem){return `<article class="card entry"><div><div class="entry-head">${ch(item.kind)}<span class="tag">${esc(item.domain)}</span></div><div class="entry-title"><h3>${esc(item.title)}</h3>${infoButton(item.kind)}</div><p>${esc(item.summary||item.content.slice(0,170))}</p></div><div class="cap-list">${item.tags.slice(0,4).map(t=>`<span class="tag">#${esc(t)}</span>`).join("")}</div><div class="item-actions"><button class="button ghost small" data-edit="${item.id}">Edit</button><button class="button soft small" data-history="${item.id}">History</button><span>v${item.version} · ${esc(item.status)}</span></div></article>`;}
async function refresh(){
  if(!token){layout("Connect to Personal Brain","Your knowledge is stored only on this computer.","",`<div class="card panel"><h2>Access your local style studio</h2><p>Start the server with <code>npm start</code>, then enter the access token printed in Terminal.</p><button class="button primary" style="margin-top:20px" data-action="token">Set Access Token</button></div>`);return;}
  try{
    summary=await api<Summary>("/api/summary");
    items=await api<RecordItem[]>("/api/items");
    await render();
  }catch(e){layout("Connection required","The local server is unavailable or your access token is invalid.","",`<div class="card panel"><h2>Check your terminal</h2><p>${esc(e instanceof Error?e.message:String(e))}</p><button class="button primary" style="margin-top:16px" data-action="token">Update Access Token</button></div>`);}
}
async function render(){
  document.querySelectorAll("[data-view]").forEach(el=>el.classList.toggle("active",(el as HTMLElement).dataset.view===active));
  $("addBtn").style.display=["history","discover","feedback","activation","trace"].includes(active)?"none":"";
  if(active==="overview")return overview();
  if(active==="discover")return discover();
  if(active==="activation")return activation();
  if(active==="feedback")return feedback();
  if(active==="history")return activity();
  if(active==="trace")return traceExplorer();
  records(active);
}
function overview(){
  const s=summary!;
  const recent=[...items].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)).slice(0,6);
  layout("Your personal intelligence","One place for your working methods, design rules and reusable skills — shared across Claude Code and Codex.",`<button class="button primary" data-action="add">＋ Create new rule</button>`,
  `<section class="metrics">${[
    ["✦",s.counts.preference,"Preferences","Global working principles"],
    ["▦",s.counts.skill,"Skills","Reusable procedures"],
    ["✓",s.counts.review,"Review rules","Quality standards"],
    ["↺",s.revisions,"Revisions","Versioned changes"]].map(a=>`<div class="card metric"><span class="icon">${a[0]}</span>${infoButton(a[2]==="Revisions"?"revision":a[2]==="Review rules"?"review":a[2]==="Skills"?"skill":"preference")}<h2>${a[1]}</h2><b>${a[2]}</b><p>${a[3]}</p></div>`).join("")}</section>
  <section class="columns"><div class="card panel"><div class="panel-head"><div><h2>Knowledge library ${infoButton("library")}</h2><p>Your most recent personal rules and skills</p></div><button class="link-btn" data-view="preference">Browse library →</button></div>${recent.map(r=>`<div class="activity-line"><span class="activity-icon">${icons[r.kind]||"◈"}</span><div class="activity-text"><b>${esc(r.title)}</b><p>${esc(r.domain)} · ${esc(r.kind)} · v${r.version}</p></div><span class="activity-time">${esc(formatTime(r.updatedAt))}</span></div>`).join("")||empty("No records","Seed sample styles to get started")}</div>
  <div><div class="callout"><div class="eyebrow">DISCOVERY FIRST</div><h2>One brain. Any agent.</h2><p>Claude and Codex receive your global style at session start, then match each task to relevant skills automatically. No discovery prompt is required.</p><button class="button primary small" data-view="discover">Try discovery →</button> <button class="button soft small" data-action="seed">Load example library</button> ${infoButton("library")}</div><div class="card panel" style="margin-top:16px"><h3>Available capability types</h3><div class="cap-list">${["Thinking","Architecture","Draw.io","Mermaid","Writing","Review","MCP tools"].map(x=>`<span class="cap-pill"><b>✧</b> ${x}</span>`).join("")}</div><p style="margin-top:20px;font-size:12px">No project memory, code indexing, agent orchestration, or cloud database.</p></div></div></section>`);
}
function records(kind:Kind){
  const matches=items.filter(r=>r.kind===kind && (domain==="all"||r.domain===domain) && (!search||[r.title,r.summary,r.content,...r.tags].join(" ").toLowerCase().includes(search.toLowerCase())));
  const desc:Record<string,string>={preference:"Your global working principles and style preferences. These apply consistently across agent runtimes.",skill:"Discoverable procedures that guide how agents perform specialized tasks.",example:"Approved references that demonstrate your preferred output quality.",review:"Reusable quality rules with optional deterministic validation checks.",tool:"Discoverable MCP capabilities. External invocation is disabled until you explicitly authorize it."};
  const toolbar=`<div class="toolbar"><input id="searchBox" class="search" type="search" placeholder="Search ${esc(kind)} records..." value="${esc(search)}" /><select id="domainFilter" class="select"><option value="all">All domains</option>${["general","thinking","architecture","diagrams","writing","reviews","communication","design","tools"].map(d=>`<option ${domain===d?"selected":""}>${d}</option>`).join("")}</select></div>`;
  layout(labels[kind],desc[kind],`<button class="button primary" data-action="add">＋ New ${esc(kind)}</button>`,`${toolbar}<section class="item-grid">${matches.map(card).join("")||empty("No matching records","Try another search or create a new record")}</section>`);
  const sb=$("searchBox") as HTMLInputElement;
  sb?.addEventListener("input",()=>{search=sb.value;const container=document.querySelector(".item-grid");if(container){const found=items.filter(r=>r.kind===kind&&(domain==="all"||r.domain===domain)&&[r.title,r.summary,r.content,...r.tags].join(" ").toLowerCase().includes(search.toLowerCase()));container.innerHTML=found.map(card).join("")||empty("No matching records","Try another search");}});
  $("domainFilter")?.addEventListener("change",ev=>{domain=(ev.target as HTMLSelectElement).value;records(kind);});
}
async function activation(){
  type AgentStatus={agent:string;file:string;installed:boolean;changed:boolean};
  const statuses=await api<{claude:AgentStatus;codex:AgentStatus}>("/api/activation");
  const states=[statuses.claude,statuses.codex];
  const pathRows=states.map(s=>`<div class="activity-line"><span class="activity-icon">${s.installed?"✓":"!"}</span><div class="activity-text"><b>${esc(s.agent==="claude"?"Claude Code":"Codex CLI")}</b><p>${esc(s.file)}</p></div><span class="chip">${s.installed?"Installed":"Not installed"}</span></div>`).join("");
  layout("Auto Activation","Both agents can load your global working style at startup, then retrieve matching skills on each prompt.","",
    `<div class="columns"><div class="card panel"><h2>Hook status ${infoButton("activation")}</h2>${pathRows}<p class="hint">Status detects installed hook definitions. It does not prove that a live CLI has executed or trusted them.</p></div><div class="card panel"><h2>Activate on macOS</h2><p>Run these commands from the project folder. The first previews the changes; the second installs MCP and lifecycle hooks.</p><div class="code-output">bash scripts/activate-personal-brain.sh<br>bash scripts/activate-personal-brain.sh --apply</div><p class="hint">Restart Claude and Codex. In Codex, open /hooks and trust the Personal Brain hooks. Existing settings are preserved and backed up.</p></div></div>
    <div class="card panel" style="margin-top:18px"><h2>Automatic behavior ${infoButton("activation")}</h2><p><b>SessionStart:</b> Load concise personal style and discovery policy. <b>UserPromptSubmit:</b> Match the task and supply relevant skill instructions automatically. This does not submit an unsolicited user prompt or require a second AI harness.</p><p style="margin-top:12px">Try: <code>npm run cli -- preview claude prompt "Draw an architecture diagram"</code></p><p class="hint">The style records update live in SQLite; new prompts receive current versions. This does not store project memory.</p></div>`);
}
function discover(){layout("Discovery Lab","Test the exact capabilities that Claude and Codex can find from Personal Brain.","",`<div class="split-box"><section class="card panel"><h2>Find the right skill ${infoButton("discover")}</h2><p>Describe the task in natural language.</p><div class="field" style="margin-top:20px"><label for="discoveryTask">Task</label><textarea id="discoveryTask" rows="4">Draw an editable IoT platform architecture diagram with clear service boundaries</textarea></div><button class="button primary" data-action="discover">Discover capabilities</button><p class="hint">Results include record IDs. Agents call brain_get to read full instructions.</p></section><section class="card panel"><h2>Discovery results</h2><div class="code-output" id="discoveryResults">Run a discovery search to inspect matching skills, styles, and tools.</div></section></div><div class="card panel" style="margin-top:18px"><h2>Baseline context ${infoButton("baseline")}</h2><p>Concise defaults for sessions; specialized instructions remain discoverable on demand.</p><button class="button soft" data-action="bootstrap" style="margin:16px 0">Show baseline</button><div class="code-output" id="bootstrapResults">Use brain_bootstrap in your agent to load the current style baseline.</div></div><div class="card panel" style="margin-top:18px"><h2>Text review simulator ${infoButton("review_simulator")}</h2><div class="field"><label>Review domain</label><select id="reviewDomain" class="select"><option>writing</option><option>diagrams</option><option>architecture</option><option>reviews</option></select></div><div class="field"><label for="reviewText">Artifact text</label><textarea id="reviewText" rows="4" placeholder="Paste document text here"></textarea></div><button class="button primary small" data-action="review">Run checks</button><div class="code-output" id="reviewResults" style="margin-top:13px;min-height:70px">Waiting for input.</div></div>`);}
async function feedback(){
  const records=await api<Array<{id:string,recordId:string|null,rating:string,note:string,createdAt:string}>>("/api/feedback");
  layout("Feedback Inbox","Record accepted work, corrections and rejected outputs. These are evidence for human-approved style updates.","",`<div class="columns"><div class="card panel"><h2>Feedback history ${infoButton("feedback")}</h2><div class="feedback-list" style="margin-top:18px">${records.map(r=>`<div class="feedback-item"><div style="display:flex;justify-content:space-between;gap:10px">${ch(r.rating)}<span class="hint">${esc(formatTime(r.createdAt))}</span></div><p>${esc(r.note)}</p></div>`).join("")||empty("No feedback","Corrections will appear here")}</div></div><div class="card panel"><h2>Capture a correction</h2><p>Feedback does not rewrite your global style automatically.</p><div class="field" style="margin-top:20px"><label>Feedback type</label><select id="fbRating"><option value="correction">Correction</option><option value="accepted">Accepted outcome</option><option value="rejected">Rejected outcome</option></select></div><div class="field"><label>Feedback</label><textarea id="fbNote" rows="6" placeholder="Explain your preference or correction"></textarea></div><button class="button primary" data-action="feedback">Record feedback</button></div></div>`);
}
async function activity(){
  const records=await api<Array<{action:string,target:string,detail:string,createdAt:string}>>("/api/audit");
  layout("Activity & Versioning","Every edit creates a new revision. Review activity and restore past versions from the library.","",`<div class="card panel"><h2>Recent activity ${infoButton("history")}</h2>${records.map(r=>`<div class="activity-line"><span class="activity-icon">↺</span><div class="activity-text"><b>${esc(r.action)} · ${esc(r.detail)}</b><p>${esc(r.target)}</p></div><span class="activity-time">${esc(formatTime(r.createdAt))}</span></div>`).join("")||empty("No activity","Create a record to start your revision history")}</div>`);
}

type TraceEntry={id:string;occurredAt:string;runId:string;agent:string;channel:string;eventType:string;outcome:string;recordIds:string[];recordVersions:Record<string,number>;metadata:Record<string,unknown>;demo:boolean};
type TraceStats={events:number;startup:number;promptMatches:number;discovery:number;retrieval:number;reviews:number;feedback:number;note:string};
let traceAgent="all",traceChannel="all",traceRecord="all",traceDemo=false;
function traceQuery(){const query=new URLSearchParams({limit:"300",agent:traceAgent,channel:traceChannel});if(traceRecord!=="all")query.set("recordId",traceRecord);if(traceDemo)query.set("demo","1");return query.toString();}
async function traceExplorer(){
  const [stats,events]=await Promise.all([api<TraceStats>("/api/trace/stats"),api<TraceEntry[]>(`/api/trace?${traceQuery()}`)]);
  const recordOptions=items.sort((a,b)=>a.title.localeCompare(b.title)).map(r=>`<option value="${esc(r.id)}" ${traceRecord===r.id?"selected":""}>${esc(r.title)} — ${esc(r.kind)}</option>`).join("");
  const kpi=[
    [stats.startup,"Startup injections","How often a session startup hook emitted baseline context"],
    [stats.promptMatches,"Task matches","How often a task hook emitted relevant instructions"],
    [stats.discovery,"Discovery calls","MCP search calls made by connected agents"],
    [stats.retrieval,"Instruction loads","Full record retrieval calls through the MCP"],
    [stats.reviews,"Review calls","Submitted artifact text validations through the MCP"]
  ];
  const reverse = traceRecord!=="all"?items.find(r=>r.id===traceRecord):null;
  const rows=events.map(e=>{
    const refs=e.recordIds.slice(0,12).map(id=>{const item=items.find(x=>x.id===id);return `<span class="trace-ref" title="Version at time of call">${esc(item?.title||id.slice(0,8))} <small>v${esc(e.recordVersions?.[id]||"?")}</small></span>`;}).join("");
    const meta=Object.entries(e.metadata||{}).map(([k,v])=>`<span><b>${esc(k)}</b> ${esc(v)}</span>`).join("");
    return `<article class="trace-event ${e.demo?"trace-demo":""}">
      <div class="trace-rail"><span class="trace-dot ${esc(e.channel)}"></span></div>
      <div class="trace-body">
        <div class="trace-heading"><div><span class="chip ${esc(e.channel)}">${esc(e.channel)}</span><b>${esc(e.eventType)}</b>${e.demo?'<span class="trace-tag">DEMO ONLY</span>':""}</div><time>${esc(formatTime(e.occurredAt))}</time></div>
        <div class="trace-sub"><span class="agent-label">${esc(e.agent)}</span><span class="trace-outcome">${esc(e.outcome)}</span><code>${esc(e.runId)}</code></div>
        ${refs?`<div class="trace-refs">${refs}</div>`:""}
        <details><summary>Inspect recorded evidence</summary><div class="trace-metadata">${meta||"No metadata was captured"}</div><p class="hint">No full prompt or agent-generated artifact is stored. MCP sessions and hooks may be unlinked.</p></details>
      </div>
    </article>`;
  }).join("");
  layout("Trace Explorer","Reverse trace how Claude and Codex receive preferences, request skills, and submit validation. Real telemetry is separate from demonstrations.","",
    `<div class="trace-alert"><div><strong>What we can prove</strong><p>Hook context emitted · MCP tool requested · Skill IDs and versions retrieved · Text checks submitted.</p></div><div><strong>What we cannot yet prove</strong><p>That the agent obeyed an instruction or that the final diagram is visually correct. Session and MCP processes may have different run IDs.</p></div></div>
    <section class="trace-metrics">${kpi.map(([value,title,description])=>`<div class="card trace-metric"><div class="trace-metric-top"><span>${esc(title)}</span>${infoButton("metrics")}</div><b>${value}</b><small>${esc(description)}</small></div>`).join("")}</section>
    <div class="card panel trace-controls">
      <div class="panel-head"><div><h2>Reverse trace ${infoButton("trace_reverse")}</h2><p>Start from an instruction or skill to find observed events and the version recorded to an agent.</p></div><button class="button soft small" data-action="trace-export">Export visible JSON</button></div>
      <div class="trace-filters">
        <label>Agent<select id="traceAgent"><option value="all">Both agents</option>${["claude","codex","unknown"].map(a=>`<option value="${a}" ${traceAgent===a?"selected":""}>${a}</option>`).join("")}</select></label>
        <label>Channel<select id="traceChannel"><option value="all">All channels</option>${["hook","mcp"].map(a=>`<option value="${a}" ${traceChannel===a?"selected":""}>${a}</option>`).join("")}</select></label>
        <label>Reverse by rule<select id="traceRecord"><option value="all">All preferences and skills</option>${recordOptions}</select></label>
        <label class="trace-demo-toggle"><input id="traceDemo" type="checkbox" ${traceDemo?"checked":""}/> Include demo traces</label>
      </div>
      ${reverse?`<div class="notice"><b>Reverse trace active:</b> ${esc(reverse.title)} — current v${reverse.version}. Event badges show the version recorded at emission, which can differ from the current version.</div>`:""}
      <div class="trace-actions"><button class="button soft small" data-action="trace-demo-seed">Generate sample traces</button>${infoButton("trace_demo")}<button class="button ghost small" data-action="trace-demo-clear">Clear sample traces</button><button class="button ghost small" data-action="trace-refresh">Refresh</button><span class="hint">${events.length} events shown · ${stats.events} real events recorded</span></div>
    </div>
    <section class="split-box" style="margin-top:18px"><div class="card panel">
       <div class="panel-head"><div><h2>Observed event timeline ${infoButton("trace")}</h2><p>Newest first. Each record was produced by a hook or MCP call.</p></div></div>
       <div class="trace-timeline">${rows||empty("No matching trace events","Run Claude or Codex with activated hooks, or generate marked sample traces to explore the format")}</div>
     </div><div class="card panel trace-guide"><h2>Evidence ladder ${infoButton("metrics")}</h2>
       <div class="evidence-stage"><span>1</span><div><b>Session initialized</b><p>Evidence a startup hook emitted context or an MCP connection occurred, not agent compliance.</p></div></div>
       <div class="evidence-stage"><span>2</span><div><b>Task instruction matched</b><p>Rule IDs and versions emitted by prompt hook.</p></div></div>
       <div class="evidence-stage"><span>3</span><div><b>Knowledge actively retrieved</b><p>Observed brain_discover and brain_get calls.</p></div></div>
       <div class="evidence-stage"><span>4</span><div><b>Artifact review requested</b><p>Observed brain_review call and deterministic result.</p></div></div>
       <div class="evidence-stage"><span>5</span><div><b>Actual effectiveness</b><p>Requires independent artifact comparison, tests, or human acceptance. Not inferred from call counts.</p></div></div>
       <div class="notice"><b>Privacy:</b> Telemetry stores event type, time, agent label, instruction IDs, versions and small metadata only. It hashes submitted prompts instead of saving them. No project memory or generated artifact content is recorded.</div>
     </div></section>`);
  for(const id of ["traceAgent","traceChannel","traceRecord","traceDemo"]){$(id).addEventListener("change",async()=>{
    traceAgent=($('traceAgent') as HTMLSelectElement).value;
    traceChannel=($('traceChannel') as HTMLSelectElement).value;
    traceRecord=($('traceRecord') as HTMLSelectElement).value;
    traceDemo=($('traceDemo') as HTMLInputElement).checked;
    await traceExplorer();
  });}
}

function openEditor(record:RecordItem|null=null){
  editing=record;
  $("editorTitle").textContent=record?`Edit ${record.title}`:"Create knowledge record";
  const fields:Record<string,string>={editKind:record?.kind||(["preference","skill","example","review","tool"].includes(active)?active:"preference"),editDomain:record?.domain||"general",editTitle:record?.title||"",editSummary:record?.summary||"",editContent:record?.content||"",editTags:record?.tags.join(", ")||"",editPriority:String(record?.priority??70),editStatus:record?.status||"active",editChecks:record?.checks.length?JSON.stringify(record.checks,null,2):"",editBackend:record?.backend?JSON.stringify(record.backend,null,2):""};
  for(const [id,value] of Object.entries(fields))($(id) as HTMLInputElement).value=value;
  $("editError").textContent="";editor.showModal();
}
function parseJson<T>(input:string,fallback:T):T{if(!input.trim())return fallback;try{return JSON.parse(input) as T;}catch{throw new Error("Invalid JSON in checks or tool backend");}}
async function saveEditor(ev:SubmitEvent){ev.preventDefault();
  try{const record={kind:($("editKind") as HTMLInputElement).value,domain:($("editDomain") as HTMLInputElement).value,title:($("editTitle") as HTMLInputElement).value,
    summary:($("editSummary") as HTMLInputElement).value,content:($("editContent") as HTMLTextAreaElement).value,
    tags:($("editTags") as HTMLInputElement).value.split(",").map(t=>t.trim()).filter(Boolean),priority:Number(($("editPriority") as HTMLInputElement).value),status:($("editStatus") as HTMLInputElement).value,
    checks:parseJson(($("editChecks") as HTMLTextAreaElement).value,[]),backend:parseJson(($("editBackend") as HTMLTextAreaElement).value,null)};
    if(record.kind==="tool"&&record.backend) {if(!confirm("External MCP tool commands can access your computer. Only configure trusted tools and leave them disabled until reviewed. Continue?"))return;}
    if(editing)await api(`/api/items/${editing.id}`,{method:"PUT",body:JSON.stringify({expectedVersion:editing.version,record})});
    else await api("/api/items",{method:"POST",body:JSON.stringify(record)});
    editor.close();toast("Saved a new version successfully");await refresh();
  }catch(e){$("editError").textContent=e instanceof Error?e.message:String(e);}
}
async function showHistory(id:string){
  const record=items.find(i=>i.id===id);if(!record)return;
  const history=await api<Array<{version:number,action:string,at:string,snapshot:RecordItem}>>(`/api/items/${id}/history`);
  $("historyTitle").textContent=record.title;
  $("historyContent").innerHTML=history.map(r=>`<div class="history-entry"><div><b>Version ${r.version} · ${esc(r.action)}</b><p>${esc(formatTime(r.at))}</p><p>${esc(r.snapshot.summary.slice(0,100))}</p></div>${r.version<record.version?`<button class="button ghost small" data-restore="${id}" data-version="${r.version}">Restore</button>`:'<span class="chip">Current</span>'}</div>`).join("");
  revisions.showModal();
}
async function restoreRecord(id:string,version:number){const rec=items.find(i=>i.id===id);if(!rec)return;
  if(!confirm(`Restore version ${version}? This creates a new version and preserves all history.`))return;
  try{await api(`/api/items/${id}/restore`,{method:"POST",body:JSON.stringify({version,expectedVersion:rec.version})});revisions.close();toast("Restored as a new version");await refresh();}catch(e){toast(e instanceof Error?e.message:String(e));}
}
async function delegated(ev:MouseEvent){const button=(ev.target as HTMLElement).closest<HTMLButtonElement>("button");if(!button)return;
  try{
    if(button.dataset.info){showHelp(button.dataset.info);return;}
    if(button.dataset.view){active=button.dataset.view as View;search="";domain="all";await render();return;}
    if(button.dataset.edit){const item=items.find(i=>i.id===button.dataset.edit);if(item)openEditor(item);return;}
    if(button.dataset.history){await showHistory(button.dataset.history);return;}
    if(button.dataset.restore){await restoreRecord(button.dataset.restore,Number(button.dataset.version));return;}
    switch(button.dataset.action){
      case "trace-demo-seed":{const r=await api<{created:number}>("/api/trace/demo",{method:"POST"});traceDemo=true;toast(`${r.created} synthetic events created`);await traceExplorer();break;}
      case "trace-demo-clear":{await api("/api/trace/demo",{method:"DELETE"});toast("Synthetic traces cleared; real telemetry unchanged");await traceExplorer();break;}
      case "trace-refresh":{await traceExplorer();break;}
      case "trace-export":{const data=await api<TraceEntry[]>(`/api/trace?${traceQuery()}`);const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),items:data},null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const link=document.createElement("a");link.href=url;link.download="personal-brain-trace.json";link.click();URL.revokeObjectURL(url);break;}
      case "seed":{const r=await api<{created:number}>("/api/examples/seed",{method:"POST"});toast(`${r.created} new examples added; existing edits preserved`);await refresh();break;}
      case "token":getToken();break;
      case "add":openEditor();break;
      case "discover":{$("discoveryResults").textContent=JSON.stringify(await api(`/api/discover?q=${encodeURIComponent(($("discoveryTask") as HTMLTextAreaElement).value)}`),null,2);break;}
      case "bootstrap":{$("bootstrapResults").textContent=(await api<{text:string}>("/api/bootstrap")).text;break;}
      case "review":{$("reviewResults").textContent=JSON.stringify(await api("/api/review",{method:"POST",body:JSON.stringify({domain:($("reviewDomain") as HTMLInputElement).value,content:($("reviewText") as HTMLTextAreaElement).value})}),null,2);break;}
      case "feedback":{const note=($("fbNote") as HTMLTextAreaElement).value.trim();if(!note)throw new Error("Feedback note required");await api("/api/feedback",{method:"POST",body:JSON.stringify({rating:($("fbRating") as HTMLSelectElement).value,note})});toast("Feedback recorded for review");await feedback();break;}
    }
  }catch(e){toast(e instanceof Error?e.message:String(e));}
}
document.addEventListener("click",delegated);
$("authBtn").addEventListener("click",getToken);
$("addBtn").addEventListener("click",()=>openEditor());
$("closeEditor").addEventListener("click",()=>editor.close());
$("cancelEditor").addEventListener("click",()=>editor.close());
$("closeRevisions").addEventListener("click",()=>revisions.close());
$("closeHelp").addEventListener("click",()=>($("helpDialog") as HTMLDialogElement).close());
$("editForm").addEventListener("submit",ev=>{void saveEditor(ev as SubmitEvent);});
void refresh();
