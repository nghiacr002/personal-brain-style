import { createInterface } from "node:readline";
import { BrainDB } from "./database.ts";
import { BrainError, KINDS, DOMAINS, type Kind, type Domain } from "./models.ts";
import { invokeBackend, inspectBackend } from "./bridge.ts";

const schemaObject = (properties:Record<string,unknown>,required:string[]=[]) => ({type:"object",properties,required,additionalProperties:false});
const text = (value:unknown) => ({content:[{type:"text",text:typeof value==="string"?value:JSON.stringify(value,null,2)}]});
const errorText=(error:unknown)=>({isError:true,content:[{type:"text",text:error instanceof Error?error.message:String(error)}]});
const str={type:"string"};

export function tools() {
  return [
    {name:"brain_bootstrap",description:"Retrieve concise global personal working style. Use at session start when you need user preferences.",inputSchema:schemaObject({})},
    {name:"brain_discover",description:"Search available personal preferences, drawing skills, writing procedures, review standards and registered MCP tools by task intent. Use before specialized work.",inputSchema:schemaObject({task:{type:"string"},kinds:{type:"array",items:{type:"string",enum:KINDS}},limit:{type:"integer",minimum:1,maximum:30}},["task"])},
    {name:"brain_get",description:"Load full content and instructions of a discovered skill, personal preference, example, or review rule.",inputSchema:schemaObject({id:str},["id"])},
    {name:"brain_style",description:"Get current personal style instructions for a specific domain.",inputSchema:schemaObject({domain:{type:"string",enum:DOMAINS}},["domain"])},
    {name:"brain_review",description:"Run stored deterministic text checks for a domain; reports subjective checks as manual.",inputSchema:schemaObject({domain:{type:"string",enum:DOMAINS},content:{type:"string"}},["content"])},
    {name:"brain_feedback",description:"Log proposed personal-style feedback for human review. Does not automatically edit styles.",inputSchema:schemaObject({rating:{type:"string",enum:["accepted","rejected","correction"]},note:str,recordId:str},["rating","note"])},
    {name:"brain_inspect_tool",description:"Inspect the tool names and schemas exposed by an enabled and approved external MCP server. Requires administrator opt-in.",inputSchema:schemaObject({id:str},["id"])},
    {name:"brain_call_tool",description:"Invoke a registered external MCP tool ONLY when approved and explicitly enabled by local administrator. Otherwise returns disabled.",inputSchema:schemaObject({id:str,arguments:{type:"object"}},["id"])},
  ];
}
export async function callTool(db:BrainDB,name:string,args:Record<string,unknown>={}) {
  try {
    switch(name) {
      case "brain_bootstrap": return text(db.bootstrap());
      case "brain_discover": {
        const task=String(args.task||"");
        if(!task || task.length>4000) throw new BrainError("Task must have 1-4000 characters");
        const kinds=Array.isArray(args.kinds)?args.kinds.filter(k=>KINDS.includes(k)):undefined;
        return text(db.discover(task,kinds as Kind[]|undefined,Number(args.limit)||12));
      }
      case "brain_get": {
        const r=db.get(String(args.id||"")); if(!r||r.status!=="active") throw new BrainError("Record not found or not active","NOT_FOUND",404);
        return text(r);
      }
      case "brain_style": {
        if(!DOMAINS.includes(args.domain as Domain)) throw new BrainError("Invalid domain");
        const domain=args.domain as Domain;
        return text(db.list({kind:"preference",status:"active"}).filter(r=>r.domain===domain||r.domain==="general").map(r=>({id:r.id,title:r.title,content:r.content,priority:r.priority,version:r.version})));
      }
      case "brain_review": {
        const content=String(args.content||""); if(content.length>150000) throw new BrainError("Artifact text exceeds 150000 characters");
        return text(db.evaluate(content,DOMAINS.includes(args.domain as Domain)?args.domain as Domain:"general"));
      }
      case "brain_feedback": {
        return text({recorded:true,approval:"pending",feedback:db.addFeedback({rating:String(args.rating||""),note:String(args.note||""),recordId:args.recordId?String(args.recordId):null})});
      }
      case "brain_inspect_tool": {
        const record=db.get(String(args.id||""));
        if(!record || record.kind!=="tool" || record.status!=="active" || !record.backend) throw new BrainError("Registered tool not found","NOT_FOUND",404);
        return text(await inspectBackend(record.backend));
      }
      case "brain_call_tool": {
        const record=db.get(String(args.id||""));
        if(!record || record.kind!=="tool" || record.status!=="active" || !record.backend) throw new BrainError("Registered tool not found","NOT_FOUND",404);
        if(args.arguments && (typeof args.arguments!=="object" || Array.isArray(args.arguments))) throw new BrainError("arguments must be object");
        return text(await invokeBackend(record.backend,args.arguments as Record<string,unknown>||{}));
      }
      default: throw new BrainError("Unknown tool", "NOT_FOUND",404);
    }
  } catch(e) {return errorText(e);}
}

export async function mcpMain(db:BrainDB) {
  // stdout is exclusively used for MCP JSON-RPC; never write log text here.
  const readline=createInterface({input:process.stdin,crlfDelay:Infinity});
  let clientName = "unknown";
  let agent: "claude" | "codex" | "unknown" = process.env.PB_AGENT==="claude" ? "claude" : process.env.PB_AGENT==="codex" ? "codex" : "unknown";
  const mcpRunId=()=>`${agent}:mcp:${process.pid}`;
  for await (const line of readline) {
    if(!line.trim())continue;
    let request:Record<string,any>;
    try { request=JSON.parse(line); } catch {process.stdout.write(JSON.stringify({jsonrpc:"2.0",id:null,error:{code:-32700,message:"Parse error"}})+"\n");continue;}
    if(request.id===undefined||request.id===null) continue; // notifications
    let response:Record<string,unknown>;
    try {
      let result:unknown;
      switch(request.method) {
        case "initialize": {
          clientName=String(request.params?.clientInfo?.name||"unknown").slice(0,80);
          if(agent==="unknown") {const n=clientName.toLowerCase();agent=n.includes("claude")?"claude":n.includes("codex")?"codex":"unknown";}
          result={protocolVersion:request.params?.protocolVersion || "2025-11-25",capabilities:{tools:{listChanged:false},resources:{listChanged:false},prompts:{listChanged:false}},serverInfo:{name:"personal-brain-style",version:"1.2.0"},instructions:"This server stores personal working style, not project data. Use brain_discover to find relevant skills and tools, then brain_get to read instructions."};
          db.trace({agent,channel:"mcp",runId:mcpRunId(),eventType:"mcp.initialize",outcome:"success",metadata:{client:clientName}});
          break;
        }
        case "ping": result={};break;
        case "tools/list": {
          result={tools:tools()};
          db.trace({agent,channel:"mcp",runId:mcpRunId(),eventType:"mcp.tools.list",outcome:"success",metadata:{count:tools().length}});
          break;
        }
        case "tools/call": {
          const name=String(request.params?.name||"").slice(0,80);
          const args=(request.params?.arguments && typeof request.params.arguments==="object") ? request.params.arguments as Record<string,unknown> : {};
          result=await callTool(db,name,args);
          const response=result as {isError?:boolean;content?:Array<{text?:string}>};
          const recordIds:string[]=[];
          if(typeof args.id==="string" && /^[a-f0-9-]{36}$/i.test(args.id)) recordIds.push(args.id);
          let resultCount=0, checkCount=0, passed=false;
          const recordVersions:Record<string,number>={};
          if(!response.isError && name==="brain_bootstrap") for(const item of db.bootstrapWithRecords().records){recordIds.push(item.id);recordVersions[item.id]=item.version;}
          if(!response.isError && response.content?.[0]?.text && ["brain_discover","brain_style","brain_review"].includes(name)) {
            try {
              const info=JSON.parse(response.content[0].text);
              if(["brain_discover","brain_style"].includes(name) && Array.isArray(info)) {resultCount=info.length;for(const row of info) if(typeof row?.id==="string") {recordIds.push(row.id);if(Number.isInteger(row.version))recordVersions[row.id]=row.version;}}
              if(name==="brain_review") {checkCount=Number(info.automated||0);passed=info.passed===true;}
            }catch {/* Never store tool payloads. */}
          }
          for(const id of recordIds) if(recordVersions[id]===undefined) {const r=db.get(id);if(r)recordVersions[id]=r.version;}
          db.trace({agent,channel:"mcp",runId:mcpRunId(),eventType:`mcp.${name}`,outcome:response.isError?"error":"success",recordIds,recordVersions,
            metadata:{tool:name,resultCount,checkCount,passed,domain:String(args.domain||"").slice(0,40),promptChars:typeof args.task==="string"?args.task.length:0}});
          break;
        }
        case "resources/list": result={resources:[{uri:"brain://style/baseline",name:"Personal working style",description:"Concise user preferences",mimeType:"text/plain"}]};break;
        case "resources/read": {
          if(request.params?.uri!=="brain://style/baseline") throw new BrainError("Unknown resource","NOT_FOUND",404);
          result={contents:[{uri:"brain://style/baseline",mimeType:"text/plain",text:db.bootstrap()}]};break;
        }
        case "prompts/list": result={prompts:[{name:"personalized_task",description:"Plan a task using personal style and skill discovery",arguments:[{name:"task",required:true}]}]};break;
        case "prompts/get": {
          if(request.params?.name!=="personalized_task") throw new BrainError("Unknown prompt");
          const task=String(request.params?.arguments?.task||"");
          result={description:"Use Personal Brain to personalize a task",messages:[{role:"user",content:{type:"text",text:`Follow my personal working style. First call brain_discover for: ${task}. Load relevant skills through brain_get, then complete the task.`}}]};break;
        }
        default: throw new BrainError("Method not found","METHOD_NOT_FOUND",404);
      }
      response={jsonrpc:"2.0",id:request.id,result};
    } catch(e) {response={jsonrpc:"2.0",id:request.id,error:{code:e instanceof BrainError&&e.code==="METHOD_NOT_FOUND"?-32601:-32602,message:e instanceof Error?e.message:String(e)}};}
    process.stdout.write(JSON.stringify(response)+"\n");
  }
}
