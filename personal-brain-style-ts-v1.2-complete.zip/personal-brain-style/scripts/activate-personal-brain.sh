#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE="$(command -v node || true)"
if [[ -z "$NODE" ]]; then echo "Node.js 22+ required"; exit 1; fi
RUNNER="$ROOT/scripts/run.mjs"
ENTRY="$ROOT/src/cli.ts"
if [[ "${1:-}" == "--apply" ]]; then
  echo "Registering MCP servers..."
  bash "$ROOT/scripts/connect-macos.sh" --apply
  echo "Installing auto-activation hooks into ~/.claude/settings.json and ~/.codex/hooks.json..."
  "$NODE" "$RUNNER" "$ENTRY" hooks install both
  printf '\nDone. Restart Claude and Codex. In Codex run /hooks and trust the two Personal Brain hooks.\n'
elif [[ "${1:-}" == "--remove" ]]; then
  "$NODE" "$RUNNER" "$ENTRY" hooks remove both
  echo "Personal Brain hooks removed. MCP registrations were left unchanged."
elif [[ "${1:-}" == "--status" ]]; then
  "$NODE" "$RUNNER" "$ENTRY" hooks status both
else
  echo "PREVIEW ONLY — no settings will be changed."
  "$NODE" "$RUNNER" "$ENTRY" hooks status both
  bash "$ROOT/scripts/connect-macos.sh"
  printf '\nTo activate MCP and hooks: bash scripts/activate-personal-brain.sh --apply\n'
  printf 'To remove only hooks: bash scripts/activate-personal-brain.sh --remove\n'
fi
