import { readFileSync } from "node:fs";
import { BrainDB, rankRecord } from "./database.ts";
import type { BrainRecord, Domain } from "./models.ts";

/** Personal Brain supplies context; it never starts a second LLM turn. */
export type AgentKind = "claude" | "codex";
export type HookPhase = "session" | "prompt";

function classify(task: string): Domain[] {
  const t = task.toLowerCase(); const result: Domain[]=[];
  if (/diagram|draw\b|drawing|drawio|draw\.io|mermaid|excalidraw|flowchart|visualiz|topology|sequence diagram|architecture diagram|sơ đồ|bản vẽ|thiết kế sơ đồ/.test(t)) result.push("diagrams");
  if (/architect|system design|solution design|microservice|integration|infrastructure|kiến trúc/.test(t)) result.push("architecture");
  if (/brd|srs|document|report|requirement|proposal|memo|specification|write|writing|viết|tài liệu/.test(t)) result.push("writing");
  if (/review|audit|verify|validate|check|critic|quality|kiểm tra|đánh giá/.test(t)) result.push("reviews");
  if (/ux|ui|prototype|wireframe|design system|mockup/.test(t)) result.push("design");
  if (/think|plan|compare|decid|tradeoff|trade-off|strategy|phân tích/.test(t)) result.push("thinking");
  return result;
}

export function startupContext(db: BrainDB): string {
  // Deliberately small, so full specialty skills can load on demand.
  const baseline=db.bootstrap(2700);
  return `${baseline}\n\nPERSONAL BRAIN AUTO ACTIVATION\n`+
    `Personal Brain is the user's global working style; it does not contain project memory. `+
    `For each substantive diagram, architecture, writing, design or review task, apply the matching skill and style automatically. `+
    `The UserPromptSubmit hook supplies task-specific instructions. `+
    `When additional information is required, call the personal-brain MCP tools brain_discover and brain_get; `+
    `use brain_inspect_tool to inspect a relevant approved integration. `+
    `Do not ask the user to request skill discovery. Respect direct user instructions over style defaults. `+
    `Never claim a tool or visual validator was run unless it actually ran.`;
}

export function taskContext(db:BrainDB, prompt: string, onMatch?: (matches:BrainRecord[],domains:Domain[])=>void): string | null {
  const task=prompt.trim().slice(0,4000);
  if(!task || task.length<4) return null;
  const domains=classify(task);
  if(domains.length===0)return null; // Avoid loading extra context for chat and unrelated commands.
  const candidates=db.list({status:"active",limit:300})
    .filter(r=>r.kind==="skill" || r.kind==="preference" || r.kind==="review" || r.kind==="example" || r.kind==="tool")
    .map(r=>({record:r,score:rankRecord(r,task)+(domains.includes(r.domain)?30:0)+(r.kind==="skill"?4:0)}))
    .filter(v=>v.score>0)
    .sort((a,b)=>b.score-a.score || b.record.priority-a.record.priority);
  const selected:BrainRecord[]=[];
  // Skills are most important; use at most 2, 2 preferences, and one review/tool hint.
  const limits:Record<string,number>={skill:2,preference:2,review:1,example:0,tool:1};
  const counts:Record<string,number>={};
  let used=0;
  for (const {record:r} of candidates) {
    if ((counts[r.kind]||0)>=(limits[r.kind]||0)) continue;
    const size=Math.min(r.content.length, r.kind==="skill"?1800:700)+140;
    if(used+size>5100)continue;
    selected.push(r);counts[r.kind]=(counts[r.kind]||0)+1;used+=size;
  }
  if(!selected.length)return null;
  onMatch?.(selected, domains);
  const sections=selected.map(r=>`[${r.kind.toUpperCase()} | ${r.domain} | ${r.title} | version ${r.version} | id ${r.id}]\n${r.content.slice(0,r.kind==="skill"?1800:700)}`).join("\n\n");
  return `PERSONAL BRAIN TASK MATCH\nAutomatically selected instructions. These are personal preferences, NOT project knowledge.\n`+
    `Apply them to the user's current task; explicit user requirements take precedence.\n\n${sections}\n\n`+
    `If a drawing or document tool is needed, discover approved MCP tools before invoking; do not invent availability. `+
    `Only claim validation when performed. Do not ask the user to load these instructions manually.`;
}

export function formatHookOutput(event:"SessionStart"|"UserPromptSubmit", context:string|null): string {
  if(!context)return "";
  return JSON.stringify({hookSpecificOutput:{hookEventName:event,additionalContext:context}});
}

export function simulateHook(db: BrainDB, agent:AgentKind, phase:HookPhase, input:unknown): string {
  // Both agents support the same event-specific JSON shape.
  void agent;
  const obj=(input && typeof input==="object" && !Array.isArray(input)) ? input as Record<string,unknown> : {};
  if(phase==="session") return formatHookOutput("SessionStart",startupContext(db));
  return formatHookOutput("UserPromptSubmit",taskContext(db,typeof obj.prompt==="string"?obj.prompt:""));
}

export function executeHook(db:BrainDB, agent:AgentKind, phase:HookPhase) {
  let input:unknown={};
  try {const raw=readFileSync(0,"utf8").slice(0,1048576);input=raw.trim()?JSON.parse(raw):{};}catch { /* Fail open when host supplies malformed input. */ }
  try {
    const obj=(input && typeof input==="object" && !Array.isArray(input)) ? input as Record<string,unknown> : {};
    const sessionId = typeof obj.session_id === "string" ? obj.session_id : typeof obj.thread_id === "string" ? obj.thread_id : null;
    const runId = sessionId ? `${agent}:${sessionId.slice(0,100)}` : `${agent}:hook:unlinked`;
    if(phase==="session") {
      const context = startupContext(db);
      db.trace({agent,channel:"hook",eventType:"hook.session.context",outcome:"emitted",runId,
        recordIds:db.bootstrapWithRecords(2700).records.map(r=>r.id),
        recordVersions:Object.fromEntries(db.bootstrapWithRecords(2700).records.map(r=>[r.id,r.version])),
        metadata:{contextChars:context.length,sessionLinked:!!sessionId}});
      process.stdout.write(formatHookOutput("SessionStart",context)+"\n");
    } else {
      const prompt = typeof obj.prompt === "string" ? obj.prompt : "";
      const matches:BrainRecord[]=[]; const domains:Domain[]=[];
      const context=taskContext(db,prompt,(found,matched)=>{matches.push(...found);domains.push(...matched);});
      db.trace({agent,channel:"hook",eventType:context?"hook.prompt.context":"hook.prompt.no_match",
        outcome:context?"emitted":"skipped",runId,recordIds:matches.map(r=>r.id),
        recordVersions:Object.fromEntries(matches.map(r=>[r.id,r.version])),metadata:{promptChars:prompt.length,
          promptHash:db.fingerprint(prompt),
          matchedDomains:domains.join(","),contextChars:context?.length||0,sessionLinked:!!sessionId}});
      if(context)process.stdout.write(formatHookOutput("UserPromptSubmit",context)+"\n");
    }
  } catch(e) { console.error(`Personal Brain hook skipped: ${e instanceof Error?e.message:String(e)}`); }
}
