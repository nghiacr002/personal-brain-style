export const KINDS = ["preference", "skill", "example", "review", "tool"] as const;
export type Kind = (typeof KINDS)[number];
export type Status = "active" | "draft" | "archived";
export const DOMAINS = ["general", "thinking", "architecture", "diagrams", "writing", "reviews", "communication", "design", "tools"] as const;
export type Domain = (typeof DOMAINS)[number];
export type TestRule = { type: "contains" | "not_contains" | "max_length" | "min_length"; value: string | number; label?: string };
export type ToolBackend = {
  command: string;
  args: string[];
  toolName: string;
  enabled: boolean;
  timeoutMs?: number;
};
export type BrainRecord = {
  id: string;
  kind: Kind;
  domain: Domain;
  title: string;
  summary: string;
  content: string;
  tags: string[];
  priority: number;
  status: Status;
  version: number;
  createdAt: string;
  updatedAt: string;
  checks: TestRule[];
  backend: ToolBackend | null;
};
export type RecordInput = Omit<BrainRecord, "id" | "version" | "createdAt" | "updatedAt">;
export type Revision = {
  id: string;
  recordId: string;
  version: number;
  action: "create" | "update" | "restore";
  snapshot: BrainRecord;
  at: string;
};
export type Feedback = { id: string; recordId: string | null; rating: "accepted" | "rejected" | "correction"; note: string; createdAt: string };
export class BrainError extends Error {
  code: string; status: number;
  constructor(message: string, code: string = "INVALID_REQUEST", status: number = 400) { super(message); this.code=code; this.status=status; }
}
export const validKind = (v: unknown): v is Kind => KINDS.includes(v as Kind);
export const validDomain = (v: unknown): v is Domain => DOMAINS.includes(v as Domain);
export const slug = (value: string) => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
